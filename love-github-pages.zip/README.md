# GitHub Pages

1. این پوشه را Upload کنید.
2. فایل `music.mp3` خود را کنار فایل‌ها قرار دهید.
3. Repository Settings > Pages > Deploy from branch > main /(root)
