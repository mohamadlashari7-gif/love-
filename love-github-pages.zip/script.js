const t='ولی من با تمام ناکاملی‌هایی که دارم، تو را حتی بیشتر از جان خود دوست می‌دارم.';
let i=0;function w(){if(i<t.length){type.textContent+=t[i++];setTimeout(w,55)}}w();
setInterval(()=>{let h=document.createElement('div');h.className='heart';h.textContent='❤';h.style.left=Math.random()*100+'vw';h.style.fontSize=(16+Math.random()*24)+'px';document.body.appendChild(h);setTimeout(()=>h.remove(),8000)},300);
document.body.addEventListener('click',()=>music.play(),{once:true});